// #define MAP_SIZE vec2(0.364, 0.364)
// #define MAP_OFFSET vec2(0.05025, 0.05025)

#define MAP_ABSOLUTE_SIZES
#define MAP_OFFSET vec2(60, 60)
#define MAP_SIZE vec2(128*2)

#define MAP_CONTENT_SIZE 127
#define MAP_CROP_RADIUS (MAP_CONTENT_SIZE/2.0)
